import os, json, datetime as dt, pandas as pd, requests, streamlit as st
from dotenv import load_dotenv
from charts import kpi_card, bar_region, donut_connection, line_daily
from agent_tools import build_agent

load_dotenv()
TOOLS_BASE = os.getenv("TOOLS_BASE", "http://localhost:8001")

st.set_page_config(page_title="Metering Analytics & Chat", layout="wide")
st.markdown("""
<style>
html, body { background: #ffffff !important; }
.sidebar .sidebar-content { background: #ffffff; }
div[data-testid="stMetric"] { background: #f7f7fb; padding: 10px; border-radius: 14px; }
</style>
""", unsafe_allow_html=True)

st.title("⚡ Metering Analytics (Gold + Silver)")

colf1, colf2, colf3 = st.columns([1,1,2])
today = dt.date.today()
default_start = today - dt.timedelta(days=30)

with colf1:
    start_date = st.date_input("Start date", value=default_start)
with colf2:
    end_date = st.date_input("End date", value=today)
with colf3:
    try:
        regions = requests.get(f"{TOOLS_BASE}/regions", timeout=10).json().get("regions", [])
    except Exception:
        regions = []
    sel_regions = st.multiselect("Regions (optional)", options=regions, default=[])

def fetch_agg():
    payload = {
        "start_date": start_date.strftime("%Y-%m-%d"),
        "end_date": end_date.strftime("%Y-%m-%d"),
    }
    if sel_regions:
        payload["regions"] = sel_regions
    r = requests.post(f"{TOOLS_BASE}/aggregate", json=payload, timeout=120)
    r.raise_for_status()
    return r.json()

data = fetch_agg()

k1, k2, k3, k4 = st.columns(4)
k1.markdown(kpi_card("Total Import", f"{data['kpis']['total_import_kwh']:.2f} kWh"), unsafe_allow_html=True)
k2.markdown(kpi_card("Total Export", f"{data['kpis']['total_export_kwh']:.2f} kWh"), unsafe_allow_html=True)
k3.markdown(kpi_card("Total MPANs", f"{int(data['kpis']['total_mpans'] or 0):,}"), unsafe_allow_html=True)
days = max(int(data['kpis'].get('days') or 1), 1)
avg = (data['kpis']['total_import_kwh'] / days) if days else 0
k4.markdown(kpi_card("Avg Daily Import", f"{avg:.2f} kWh/day"), unsafe_allow_html=True)

c1, c2 = st.columns([1.2, 1])
with c1:
    st.subheader("Import by Region")
    df_region = pd.DataFrame(data["by_region"])
    if not df_region.empty:
        st.plotly_chart(bar_region(df_region), use_container_width=True)
    else:
        st.info("No region data for the selected filters.")
with c2:
    st.subheader("By Connection Type")
    df_conn = pd.DataFrame(data["by_connection_type"])
    if not df_conn.empty:
        st.plotly_chart(donut_connection(df_conn), use_container_width=True)
    else:
        st.info("No connection type distribution available.")

st.subheader("Daily Import Trend")
df_daily = pd.DataFrame(data["daily"])
if not df_daily.empty:
    st.plotly_chart(line_daily(df_daily), use_container_width=True)
else:
    st.info("No daily points for the selected date range.")

st.divider()

st.subheader("Ask the data (Agentic NL Chat)")
agent, tools = build_agent()

with st.expander("What can I ask?", expanded=False):
    st.write("""
- “Show import by region for last week.”
- “What’s the average daily consumption for Yorkshire in August?”
- “List tables in sdr_gold_dev.meter_data”
- “Show columns in sdr_silver_dev.silver_meter_data.tbl_meterdata”
""")

if "history" not in st.session_state:
    st.session_state.history = []

for role, msg in st.session_state.history:
    st.chat_message(role).markdown(msg)

prompt = st.chat_input("e.g., total import for London last 14 days")
if prompt:
    st.session_state.history.append(("user", prompt))
    st.chat_message("user").markdown(prompt)

    system_hint = f"Use the available tools. Today is {dt.date.today()}. Default date window: last 30 days if unspecified."
    q = f"{system_hint}\n\nUser: {prompt}"

    with st.chat_message("assistant"):
        try:
            resp = agent.run(q)
        except Exception as e:
            resp = f"Error: {e}"
        st.markdown(resp)
    st.session_state.history.append(("assistant", resp))
