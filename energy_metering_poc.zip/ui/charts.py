import pandas as pd
import plotly.express as px

def kpi_card(title: str, value: str, sub: str = ""):
    return f"""
    <div style="padding:12px 16px;border-radius:14px;background:#f7f7fb;box-shadow:0 1px 3px rgba(0,0,0,0.06);">
      <div style="font-size:12px;color:#666">{title}</div>
      <div style="font-size:28px;font-weight:700;margin:4px 0">{value}</div>
      <div style="font-size:12px;color:#888">{sub}</div>
    </div>"""

def bar_region(df: pd.DataFrame):
    fig = px.bar(df, x="region", y="import_kwh")
    fig.update_layout(margin=dict(l=0,r=0,t=10,b=0), xaxis_title="", yaxis_title="Import (kWh)")
    return fig

def donut_connection(df: pd.DataFrame):
    fig = px.pie(df, names="connection_type", values="import_kwh", hole=0.55)
    fig.update_layout(margin=dict(l=0,r=0,t=10,b=0))
    return fig

def line_daily(df: pd.DataFrame):
    fig = px.line(df, x="reading_date", y="import_kwh")
    fig.update_layout(margin=dict(l=0,r=0,t=10,b=0), xaxis_title="", yaxis_title="Import (kWh)")
    return fig
