import os, requests, json
from dotenv import load_dotenv
from langchain.tools import Tool
from langchain_openai import AzureChatOpenAI, ChatOpenAI

load_dotenv()

TOOLS_BASE = os.getenv("TOOLS_BASE", "http://localhost:8001")

def _post(path: str, payload: dict) -> dict:
    r = requests.post(f"{TOOLS_BASE}{path}", json=payload, timeout=90)
    r.raise_for_status()
    return r.json()

def _get(path: str) -> dict:
    r = requests.get(f"{TOOLS_BASE}{path}", timeout=30)
    r.raise_for_status()
    return r.json()

def tool_list_tables():
    def _run(q: str) -> str:
        catalog, schema = q.split(".")
        out = _post("/list-tables", {"catalog": catalog, "schema": schema})
        import json as _json
        return _json.dumps(out, indent=2)
    return Tool.from_function(name="list_tables", description="List tables in catalog.schema (input: 'catalog.schema')", func=_run)

def tool_list_columns():
    def _run(q: str) -> str:
        catalog, schema, table = q.split(".")
        out = _post("/list-columns", {"catalog": catalog, "schema": schema, "table": table})
        import json as _json
        return _json.dumps(out, indent=2)
    return Tool.from_function(name="list_columns", description="List columns for catalog.schema.table", func=_run)

def tool_regions():
    def _run(_: str) -> str:
        import json as _json
        return _json.dumps(_get("/regions"), indent=2)
    return Tool.from_function(name="list_regions", description="List known regions from meter metadata. Input ignored.", func=_run)

def tool_aggregate():
    def _run(q: str) -> str:
        payload = json.loads(q)
        out = _post("/aggregate", payload)
        import json as _json
        return _json.dumps(out, indent=2)
    return Tool.from_function(name="aggregate_consumption", description="Aggregate consumption between dates with optional regions. Input JSON: {start_date, end_date, regions?}", func=_run)

def get_llm():
    if os.getenv("AZURE_OPENAI_API_KEY"):
        return AzureChatOpenAI(
            azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT"),
            azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            temperature=0.1,
        )
    return ChatOpenAI(model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"), temperature=0.1)

SYSTEM = """You are a metering data analyst.
Use tools to answer questions with numbers and dates. Prefer `aggregate_consumption` for KPIs and charts.
When user asks schema/table/columns, use list_* tools.
If filters (date range / region) are unspecified, infer sensible defaults (last 30 days, all regions).
Return concise answers and, when applicable, a compact JSON block 'data_for_plot' with keys: by_region, by_connection_type, daily.
"""

def build_agent():
    llm = get_llm()
    tools = [tool_list_tables(), tool_list_columns(), tool_regions(), tool_aggregate()]
    from langchain.agents import initialize_agent, AgentType
    return initialize_agent(tools, llm, agent=AgentType.OPENAI_FUNCTIONS, verbose=False, max_iterations=4, handle_parsing_errors=True), tools
