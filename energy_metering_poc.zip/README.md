# Energy Metering PoC (Databricks + Azure ML + MCP + Agentic Chat)

## 1) Start the MCP tools server
```
cd mcp_server
pip install -r requirements.txt
cp ../.env.sample ../.env  # fill your secrets
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

## 2) Run the UI
```
cd ../ui
pip install -r requirements.txt
streamlit run app.py
```

### Expected Tables
- GOLD: `sdr_gold_dev.meter_data.daily_readings` with columns:
  - `mpan`, `reading_date` (DATE), `import_kwh` (DOUBLE), `export_kwh` (DOUBLE), `mpan_count` (BIGINT)
- SILVER: `sdr_silver_dev.silver_meter_data.tbl_meterdata` with columns:
  - `mpan`, `region` or `gsp_group`, `connection_type`

If your names differ, edit SQL in `mcp_server/server.py` (four queries).

### Notes
- Region list cache refreshes every 30 minutes (APScheduler).
- The chat agent calls tools: list tables/columns, regions, and aggregate KPI endpoint.
- Keep access via a Databricks **SQL Warehouse** for governance.
