from pydantic import BaseModel, Field
from typing import Optional, List

class ListTablesInSchemaRequest(BaseModel):
    catalog: str
    schema: str

class ListTablesInSchemaResponse(BaseModel):
    tables: List[str]

class ListColumnsRequest(BaseModel):
    catalog: str
    schema: str
    table: str

class ColumnInfo(BaseModel):
    name: str
    data_type: str
    nullable: bool

class ListColumnsResponse(BaseModel):
    columns: List[ColumnInfo]

class AggregateConsumptionRequest(BaseModel):
    start_date: str = Field(..., description="YYYY-MM-DD")
    end_date: str = Field(..., description="YYYY-MM-DD")
    regions: Optional[List[str]] = None

class AggregateConsumptionResponse(BaseModel):
    kpis: dict
    by_region: list
    by_connection_type: list
    daily: list

class NLQueryRequest(BaseModel):
    question: str
    max_rows: int = 200
