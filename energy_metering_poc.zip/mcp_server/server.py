import os
from datetime import datetime
from typing import Any
from fastapi import FastAPI
from apscheduler.schedulers.background import BackgroundScheduler
from dotenv import load_dotenv
from .db import run_query
from .tool_schemas import (
    ListTablesInSchemaRequest, ListTablesInSchemaResponse,
    ListColumnsRequest, ListColumnsResponse,
    AggregateConsumptionRequest, AggregateConsumptionResponse,
    NLQueryRequest
)

load_dotenv()

CATALOG_GOLD = os.getenv("CATALOG_GOLD", "sdr_gold_dev")
SCHEMA_METER = os.getenv("SCHEMA_METER", "meter_data")
CATALOG_SILVER = os.getenv("CATALOG_SILVER", "sdr_silver_dev")
SCHEMA_SILVER = os.getenv("SCHEMA_SILVER", "silver_meter_data")
TABLE_METERDATA = os.getenv("TABLE_METERDATA", "tbl_meterdata")

CACHE: dict[str, Any] = {"last_refresh": None, "regions": []}

def refresh_cache():
    try:
        rows = run_query(f"""
            SELECT DISTINCT COALESCE(region, gsp_group, "Unknown") AS region
            FROM {CATALOG_SILVER}.{SCHEMA_SILVER}.{TABLE_METERDATA}
            WHERE region IS NOT NULL OR gsp_group IS NOT NULL
            ORDER BY 1
        """)
        CACHE["regions"] = [r["region"] for r in rows]
        CACHE["last_refresh"] = datetime.utcnow().isoformat()
        print(f"[cache] refreshed at {CACHE['last_refresh']} with {len(CACHE['regions'])} regions")
    except Exception as e:
        print("[cache] refresh failed:", e)

app = FastAPI(title="Energy MCP Tools")

@app.on_event("startup")
def _startup():
    refresh_cache()
    sched = BackgroundScheduler(daemon=True)
    sched.add_job(refresh_cache, "interval", minutes=30)
    sched.start()

@app.get("/health")
def health():
    return {"ok": True, "cache_refreshed_utc": CACHE["last_refresh"]}

@app.get("/list-catalogs")
def list_catalogs():
    rows = run_query("SHOW CATALOGS")
    key = list(rows[0].keys())[0] if rows else "catalog"
    return {"catalogs": [r[key] for r in rows]}

@app.post("/list-tables", response_model=ListTablesInSchemaResponse)
def list_tables(req: ListTablesInSchemaRequest):
    rows = run_query(f"""
        SELECT table_name
        FROM {req.catalog}.information_schema.tables
        WHERE table_schema = %(schema)s
        ORDER BY table_name
    """, {"schema": req.schema})
    return {"tables": [r["table_name"] for r in rows]}

@app.post("/list-columns", response_model=ListColumnsResponse)
def list_columns(req: ListColumnsRequest):
    rows = run_query(f"""
        SELECT column_name, data_type, is_nullable
        FROM {req.catalog}.information_schema.columns
        WHERE table_schema=%(schema)s AND table_name=%(table)s
        ORDER BY ordinal_position
    """, {"schema": req.schema, "table": req.table})
    return {"columns": [
        {"name": r["column_name"], "data_type": r["data_type"], "nullable": r["is_nullable"] == "YES"}
        for r in rows
    ]}

@app.get("/regions")
def regions():
    return {"regions": CACHE["regions"]}

@app.post("/aggregate", response_model=AggregateConsumptionResponse)
def aggregate(req: AggregateConsumptionRequest):
    regions_filter = ""
    params = {"start": req.start_date, "end": req.end_date}
    if req.regions:
        regions_filter = " AND COALESCE(m.region, m.gsp_group) IN %(regions)s "
        params["regions"] = tuple(req.regions)

    rows_kpi = run_query(f"""
        WITH joined AS (
          SELECT
            d.reading_date,
            COALESCE(m.region, m.gsp_group, "Unknown") AS region,
            COALESCE(m.connection_type, "Unknown") AS connection_type,
            CAST(d.import_kwh AS DOUBLE) AS import_kwh,
            CAST(d.export_kwh AS DOUBLE) AS export_kwh,
            CAST(d.mpan_count AS BIGINT) AS mpans
          FROM {CATALOG_GOLD}.{SCHEMA_METER}.daily_readings d
          LEFT JOIN {CATALOG_SILVER}.{SCHEMA_SILVER}.{TABLE_METERDATA} m
            ON d.mpan = m.mpan
          WHERE d.reading_date BETWEEN %(start)s AND %(end)s
          {regions_filter}
        )
        SELECT
          SUM(import_kwh) AS total_import_kwh,
          SUM(export_kwh) AS total_export_kwh,
          SUM(mpans)      AS total_mpans,
          COUNT(DISTINCT reading_date) AS days
        FROM joined
    """, params)

    kpis = rows_kpi[0] if rows_kpi else {"total_import_kwh": 0, "total_export_kwh": 0, "total_mpans": 0, "days": 0}

    by_region = run_query(f"""
        WITH joined AS (
          SELECT
            COALESCE(m.region, m.gsp_group, "Unknown") AS region,
            CAST(d.import_kwh AS DOUBLE) AS import_kwh
          FROM {CATALOG_GOLD}.{SCHEMA_METER}.daily_readings d
          LEFT JOIN {CATALOG_SILVER}.{SCHEMA_SILVER}.{TABLE_METERDATA} m
            ON d.mpan = m.mpan
          WHERE d.reading_date BETWEEN %(start)s AND %(end)s
          {regions_filter}
        )
        SELECT region, SUM(import_kwh) AS import_kwh
        FROM joined GROUP BY region ORDER BY import_kwh DESC
    """, params)

    by_conn = run_query(f"""
        WITH joined AS (
          SELECT
            COALESCE(m.connection_type, "Unknown") AS connection_type,
            CAST(d.import_kwh AS DOUBLE) AS import_kwh
          FROM {CATALOG_GOLD}.{SCHEMA_METER}.daily_readings d
          LEFT JOIN {CATALOG_SILVER}.{SCHEMA_SILVER}.{TABLE_METERDATA} m
            ON d.mpan = m.mpan
          WHERE d.reading_date BETWEEN %(start)s AND %(end)s
          {regions_filter}
        )
        SELECT connection_type, SUM(import_kwh) AS import_kwh
        FROM joined GROUP BY connection_type ORDER BY import_kwh DESC
    """, params)

    daily = run_query(f"""
        WITH joined AS (
          SELECT
            d.reading_date,
            CAST(d.import_kwh AS DOUBLE) AS import_kwh
          FROM {CATALOG_GOLD}.{SCHEMA_METER}.daily_readings d
          LEFT JOIN {CATALOG_SILVER}.{SCHEMA_SILVER}.{TABLE_METERDATA} m
            ON d.mpan = m.mpan
          WHERE d.reading_date BETWEEN %(start)s AND %(end)s
          {regions_filter}
        )
        SELECT reading_date, SUM(import_kwh) AS import_kwh
        FROM joined GROUP BY reading_date ORDER BY reading_date
    """, params)

    return {
        "kpis": kpis,
        "by_region": by_region,
        "by_connection_type": by_conn,
        "daily": daily
    }

@app.post("/nl-query")
def nl_query(req: NLQueryRequest):
    return {"message": "Use the agent to translate NL to SQL safely against information_schema.", "max_rows": req.max_rows}
