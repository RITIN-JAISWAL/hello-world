import os
from databricks import sql

HOST = os.getenv("DATABRICKS_HOST")
HTTP_PATH = os.getenv("DATABRICKS_HTTP_PATH")
TOKEN = os.getenv("DATABRICKS_TOKEN")

def get_conn():
    return sql.connect(server_hostname=HOST, http_path=HTTP_PATH, access_token=TOKEN)

def run_query(q: str, params: dict | None = None) -> list[dict]:
    with get_conn() as c:
        with c.cursor() as cur:
            cur.execute(q, params or {})
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, r)) for r in cur.fetchall()]
