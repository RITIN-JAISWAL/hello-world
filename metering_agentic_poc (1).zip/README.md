# Metering Agentic AI – Settlement POC

Connects to Databricks Unity Catalog:
- Gold: `sdr_gold_dev.meter_data` (browse tables, preview)
- Silver: `sdr_silver_dev.silver_meter_data.tbl_meterdata` (facts)

## Run (Azure VM / AML)
```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell
# .venv\Scripts\Activate.ps1

pip install -r requirements.txt

# Copy env and fill
cp .env.example .env  # PowerShell: copy .env.example .env

# Launch (port 6006 works well behind AML proxy)
streamlit run app.py --server.address 0.0.0.0 --server.port 6006
```
Open inside AML:
```
https://<compute-name>.<region>.instances.azureml.ms/proxy/6006/
```

## PowerShell env example
```powershell
$env:DATABRICKS_HOST="adb-xxxxxxxx.azuredatabricks.net"
$env:DATABRICKS_HTTP_PATH="/sql/1.0/warehouses/xxxx"
$env:DATABRICKS_TOKEN="dapi_xxx"
```

## Optional MCP
```bash
python mcp_server/databricks_mcp.py
```
