import os, re, json, time
import pandas as pd
from databricks import sql
from typing import Optional, Dict, Any

HOST = os.getenv("DATABRICKS_HOST")
HTTP_PATH = os.getenv("DATABRICKS_HTTP_PATH")
TOKEN = os.getenv("DATABRICKS_TOKEN")

GOLD_CATALOG = os.getenv("GOLD_CATALOG_NAME","sdr_gold_dev")
GOLD_SCHEMA  = os.getenv("GOLD_SCHEMA_NAME","meter_data")
SILVER_CATALOG = os.getenv("SILVER_CATALOG_NAME","sdr_silver_dev")
SILVER_SCHEMA  = os.getenv("SILVER_SCHEMA_NAME","silver_meter_data")
SILVER_TABLE   = os.getenv("SILVER_TABLE_NAME","tbl_meterdata")

# light cache valid for 25 minutes (align with 30-min refresh)
_cache: Dict[str, Any] = {"ts": 0, "semantic": None}
TTL = 25*60

def _connect():
    if not (HOST and HTTP_PATH and TOKEN):
        raise RuntimeError("Databricks SQL creds missing. Set DATABRICKS_HOST/HTTP_PATH/TOKEN")
    return sql.connect(server_hostname=HOST, http_path=HTTP_PATH, access_token=TOKEN)

def query_df(query: str) -> pd.DataFrame:
    conn = None
    try:
        conn = _connect()
        with conn.cursor() as c:
            c.execute(query)
            rows = c.fetchall()
            cols = [d[0] for d in c.description]
        return pd.DataFrame(rows, columns=cols)
    finally:
        if conn: conn.close()

def discover_tables(catalog: str, schema: str) -> pd.DataFrame:
    q = f"""
    SELECT table_name
    FROM system.information_schema.tables
    WHERE table_catalog = '{catalog}'
      AND table_schema  = '{schema}'
    ORDER BY table_name
    """
    return query_df(q)

def head_table(catalog: str, schema: str, table: str, n: int = 5) -> pd.DataFrame:
    fq = f"{catalog}.{schema}.{table}"
    return query_df(f"SELECT * FROM {fq} LIMIT {n}")

def _columns(catalog: str, schema: str, table: str) -> pd.DataFrame:
    q = f"""
    SELECT column_name, data_type
    FROM system.information_schema.columns
    WHERE table_catalog='{catalog}' AND table_schema='{schema}' AND table_name='{table}'
    """
    return query_df(q)

def _best_col(cols, patterns):
    # patterns: list of regex
    lower = {c.lower(): c for c in cols}
    for pat in patterns:
        r = re.compile(pat, re.I)
        for lc, orig in lower.items():
            if r.search(lc):
                return orig
    return None

def infer_semantic_map() -> Dict[str, Any]:
    global _cache
    now = time.time()
    if _cache["semantic"] and now - _cache["ts"] < TTL:
        return _cache["semantic"]

    # 1) try find gold daily MV
    gold_tables = discover_tables(GOLD_CATALOG, GOLD_SCHEMA)["table_name"].str.lower().tolist()
    gold_daily_mv = next((t for t in gold_tables if t.startswith("mv_agg_meterdata_daily")), None)

    # 2) dim tables presence
    dim_gsp = "dim_gspgroup" if "dim_gspgroup" in gold_tables else None
    dim_halfhour = "dim_halfhour" if "dim_halfhour" in gold_tables else None

    # 3) silver columns detection
    silver_cols = _columns(SILVER_CATALOG, SILVER_SCHEMA, SILVER_TABLE)
    colnames = silver_cols["column_name"].tolist()

    date_col = _best_col(colnames, [r"UTCSettlementDate", r"settlement.*date", r".*date$"])
    value_col= _best_col(colnames, [r"UTCPeriodConsumptionValue", r"kwh|consumption|energy|^value$"])
    region_col=_best_col(colnames, [r"region", r"gsp.?group.*", r"^gspgroupid$"])
    mpan_col = _best_col(colnames, [r"mpan", r"mpancore"])
    period_col=_best_col(colnames, [r"settlementperiod", r"period$"])

    semantic = {
        "gold": {
            "catalog": GOLD_CATALOG, "schema": GOLD_SCHEMA,
            "daily_mv": gold_daily_mv,
            "dim_gspgroup": dim_gsp,
            "dim_halfhour": dim_halfhour
        },
        "silver": {
            "catalog": SILVER_CATALOG, "schema": SILVER_SCHEMA, "table": SILVER_TABLE,
            "date_col": date_col, "value_col": value_col, "region_col": region_col,
            "mpan_col": mpan_col, "period_col": period_col
        }
    }
    _cache = {"ts": now, "semantic": semantic}
    return semantic

def agg_daily(start_date: str, end_date: str, region: Optional[str]=None) -> pd.DataFrame:
    S = infer_semantic_map()
    # Try gold daily MV first
    if S["gold"]["daily_mv"]:
        mv = f"{S['gold']['catalog']}.{S['gold']['schema']}.{S['gold']['daily_mv']}"
        region_join = ""
        region_field = "f.GSPGroupID"
        if S["gold"]["dim_gspgroup"]:
            g = f"{S['gold']['catalog']}.{S['gold']['schema']}.{S['gold']['dim_gspgroup']}"
            region_join = f" LEFT JOIN {g} g ON f.GSPGroupID=g.GSPGroupID "
            region_field = "COALESCE(g.RegionName, f.GSPGroupID)"
        region_pred = f" AND {region_field} = '{region}'" if region else ""
        q = f"""
        SELECT f.UTCSettlementDate AS reading_date,
               {region_field} AS region,
               SUM(f.total_kwh) AS total_kwh
        FROM {mv} f
        {region_join}
        WHERE f.UTCSettlementDate >= '{start_date}' AND f.UTCSettlementDate <= '{end_date}' {region_pred}
        GROUP BY f.UTCSettlementDate, {region_field}
        ORDER BY reading_date
        """
        try:
            return query_df(q)
        except Exception:
            pass

    # Fallback to silver
    s = S["silver"]
    fq = f"{s['catalog']}.{s['schema']}.{s['table']}"
    date_col = s["date_col"]; value_col = s["value_col"]; region_col = s["region_col"]
    if not (date_col and value_col):
        raise RuntimeError("Could not infer date/value columns from silver table automatically.")
    region_pred = f" AND {region_col} = '{region}'" if region and region_col else ""
    reg_sel = f"COALESCE({region_col}, 'Unknown')" if region_col else "'All'"
    q = f"""
    SELECT {date_col} AS reading_date,
           {reg_sel} AS region,
           SUM({value_col}) AS total_kwh
    FROM {fq}
    WHERE {date_col} >= '{start_date}' AND {date_col} <= '{end_date}' {region_pred}
    GROUP BY {date_col}, {reg_sel}
    ORDER BY reading_date
    """
    return query_df(q)

def import_export_breakdown(start_date: str, end_date: str, region: Optional[str]=None) -> pd.DataFrame:
    S = infer_semantic_map()
    s = S["silver"]
    fq = f"{s['catalog']}.{s['schema']}.{s['table']}"
    date_col = s["date_col"]; value_col = s["value_col"]; region_col = s["region_col"]
    if not (date_col and value_col):
        raise RuntimeError("Could not infer date/value columns from silver table automatically.")
    region_pred = f" AND {region_col} = '{region}'" if region and region_col else ""
    q = f"""
    SELECT CASE WHEN {value_col} >= 0 THEN 'Import' ELSE 'Export' END AS import_export_flag,
           SUM(ABS({value_col})) AS kwh_consumed
    FROM {fq}
    WHERE {date_col} >= '{start_date}' AND {date_col} <= '{end_date}' {region_pred}
    GROUP BY CASE WHEN {value_col} >= 0 THEN 'Import' ELSE 'Export' END
    """
    return query_df(q)

def peak_offpeak(start_date: str, end_date: str, region: Optional[str]=None) -> pd.DataFrame:
    S = infer_semantic_map()
    s = S["silver"]
    fq = f"{s['catalog']}.{s['schema']}.{s['table']}"
    date_col = s["date_col"]; value_col = s["value_col"]; region_col = s["region_col"]; period_col = s["period_col"]
    if S["gold"]["dim_halfhour"] and period_col:
        hh = f"{S['gold']['catalog']}.{S['gold']['schema']}.{S['gold']['dim_halfhour']}"
        region_pred = f" AND ({region_col} = '{region}')" if region and region_col else ""
        q = f"""
        SELECT {date_col} AS reading_date,
               SUM(CASE WHEN COALESCE(hh.IsPeak, false) THEN {value_col} ELSE 0 END) AS peak_kwh,
               SUM(CASE WHEN NOT COALESCE(hh.IsPeak, false) THEN {value_col} ELSE 0 END) AS offpeak_kwh
        FROM {fq} s
        LEFT JOIN {hh} hh ON s.{period_col} = hh.SettlementPeriod
        WHERE {date_col} >= '{start_date}' AND {date_col} <= '{end_date}' {region_pred}
        GROUP BY {date_col}
        ORDER BY reading_date
        """
        try:
            return query_df(q)
        except Exception:
            pass
    # Fallback with no split
    return agg_daily(start_date, end_date, region)[["reading_date"]].assign(peak_kwh=None, offpeak_kwh=None)

# Convenience for the UI/agent
def get_semantic_map_json() -> str:
    return json.dumps(infer_semantic_map(), indent=2)
