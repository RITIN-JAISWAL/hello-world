import plotly.express as px

def line_consumption(df):
    fig = px.line(df, x="reading_date", y="total_kwh", color="region", markers=True)
    fig.update_layout(height=320, margin=dict(l=10,r=10,t=30,b=10))
    return fig

def pie_import_export(df):
    fig = px.pie(df, names="import_export_flag", values="kwh_consumed", hole=0.5)
    fig.update_layout(height=250, margin=dict(l=10,r=10,t=30,b=0))
    return fig
