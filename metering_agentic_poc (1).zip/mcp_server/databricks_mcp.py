import os
from fastmcp import FastMCP
from src.data_access import dbx

app = FastMCP("metering-mcp")

@app.tool()
def infer_schema() -> str:
    """Return the inferred semantic map (tables/columns) as JSON (auto-discovered from information_schema)."""
    return dbx.get_semantic_map_json()

@app.tool()
def list_gold_tables() -> str:
    s = dbx.infer_semantic_map()
    df = dbx.discover_tables(s["gold"]["catalog"], s["gold"]["schema"])
    return "\n".join(df["table_name"].tolist())

@app.tool()
def head_gold_table(table_name: str, limit:int=5) -> str:
    s = dbx.infer_semantic_map()
    df = dbx.head_table(s["gold"]["catalog"], s["gold"]["schema"], table_name, limit)
    return df.to_markdown(index=False)

@app.tool()
def agg_daily(start_date: str, end_date: str, region: str = None) -> str:
    df = dbx.agg_daily(start_date, end_date, region)
    return df.to_json(orient="records")

@app.tool()
def import_export(start_date: str, end_date: str, region: str = None) -> str:
    df = dbx.import_export_breakdown(start_date, end_date, region)
    return df.to_json(orient="records")

@app.tool()
def peak_offpeak(start_date: str, end_date: str, region: str = None) -> str:
    df = dbx.peak_offpeak(start_date, end_date, region)
    return df.to_json(orient="records")

if __name__ == "__main__":
    app.run()
